package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class StaffActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DishAdapter dishAdapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Chiamata API per recuperare i dati dei piatti da fare
        fetchDishes();
    }

    private <DishService, Dish> void fetchDishes() {
        Object RetrofitClientInstance = null;
        DishService dishService = RetrofitClientInstance.toString().chars(DishService.class);
        Call<List<Dish>> call = dishService.getDishes();
        call.enqueue(new Callback<List<Dish>>() {
            @Override
            public void onResponse(Call<List<Dish>> call, Response<List<Dish>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Dish> dishes = response.body();
                    dishAdapter = new DishAdapter(dishes);
                    recyclerView.setAdapter(dishAdapter);
                } else {
                    // Gestione dell'errore
                }
            }

            @Override
            public void onFailure(Call<List<Dish>> call, Throwable t) {
                // Gestione dell'errore
            }
        });
    }
}
