package com.example.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText emailEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailEditText = findViewById(R.id.editTextTextEmailAddress);
        passwordEditText = findViewById(R.id.editTextTextPassword);
    }

    public void loginUser(View view) {
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Esegui il login solo se entrambi i campi sono stati compilati
        if (!email.isEmpty() && !password.isEmpty()) {
            new LoginTask().execute(email, password);
        } else {
            Toast.makeText(this, "Inserisci email e password", Toast.LENGTH_SHORT).show();
        }
    }

    // AsyncTask per eseguire il login in background
    private class LoginTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String email = params[0];
            String password = params[1];

            try {
                // URLweb service per l'autenticazione
                URL url = new URL("bisogna mettere il webservice");

                // Crea una connessione HTTP
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                // Crea il corpo della richiesta JSON con email e password
                String requestBody = "{\"email\": \"" + email + "\", \"password\": \"" + password + "\"}";

                // Invia i dati della richiesta
                OutputStream outputStream = connection.getOutputStream();
                outputStream.write(requestBody.getBytes());
                outputStream.flush();
                outputStream.close();

                // Leggi la risposta dal server
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Ritorna la risposta del server
                return response.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String response) {
            // Gestisci la risposta del server qui
            if (response != null) {
                if (response.equals("success")) {
                    // Login riuscito
                    Toast.makeText(MainActivity.this, "Login effettuato con successo", Toast.LENGTH_SHORT).show();
                } else {
                    // Login fallito
                    Toast.makeText(MainActivity.this, "Credenziali non valide", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Errore durante la connessione al server
                Toast.makeText(MainActivity.this, "Errore di connessione", Toast.LENGTH_SHORT).show();
            }
        }
        public void openStaffActivity(View view) {
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Esegui il login solo se entrambi i campi sono stati compilati
            if (!email.isEmpty() && !password.isEmpty()) {
                new LoginTask().execute(email, password);
            } else {
                Toast.makeText(this, "Inserisci email e password", Toast.LENGTH_SHORT).show();
            }
        }
        public void openCustomerActivity(View view) {
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Esegui il login solo se entrambi i campi sono stati compilati
            if (!email.isEmpty() && !password.isEmpty()) {
                new LoginTask().execute(email, password);
            } else {
                Toast.makeText(this, "Inserisci email e password", Toast.LENGTH_SHORT).show();
            }
        }
    }
}